from  machine import Pin, time_pulse_us, PWM
import time
from time import sleep_us, sleep
import network, ujson, dht
from umqtt.simple import MQTTClient

SERVO_PIN= 2

trigger = Pin(19, Pin.OUT)
echo = Pin(18, Pin.IN)
pwm = PWM(Pin(SERVO_PIN), freq=50, duty=0)

ledVermelho = Pin(4, Pin.OUT)
ledAmarelo = Pin(16, Pin.OUT)
ledVerde = Pin(17, Pin.OUT)


def calcular_dist():
  trigger.value(0)
  sleep_us(2)

  trigger.value(1)
  sleep_us(10)
  trigger.value(0)

  return time_pulse_us(echo, 1) * 0.0343 / 2

MQTT_CLIENT_ID = "qqlcoisanpodeterdoisdomesmo"
MQTT_BROKER = "broker.mqttdashboard.com"
MQTT_TOPIC = "medidaedistanciaa"
MQTT_TOPIC_SUBSCRIBE = "controle_servrtfdoHenry"


def connect_to_wifi():
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)
    sta_if.connect('Wokwi-GUEST', '')
    while not sta_if.isconnected():
        print(".", end="")
        time.sleep(0.1)
    print(" Connected!")


def connect_to_mqtt():
    print("Connecting to MQTT server... ", end="")
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER)
    client.connect()
    print("Connected!")
    return client


print("Connecting to WiFi", end="")
connect_to_wifi()


def on_message(topic, msg):
    angle = msg.decode('utf-8')
    try:
        angle = int(angle)
        if 0 <= angle <= 100:
            duty_cycle = int(((angle) / 180 * 2 + 0.5) / 20 * 1023)
            pwm.duty(duty_cycle)
            print(f"Servo movido para {angle} cm")
        else:
            print("Ângulo fora do intervalo (0-100 cm)")
    except ValueError:
        print("Mensagem inválida recebida")


client = connect_to_mqtt()
client.set_callback(on_message)
client.subscribe(MQTT_TOPIC_SUBSCRIBE)

def main():
  while True:
    distance = calcular_dist()
    if distance is not None:
        message = ujson.dumps({"distance": distance})
        client.publish(MQTT_TOPIC, message)
        print(f'Distância: {distance:.2f} cm')
    else:
        print("Falha na medição de distância")

    if (distance >= 75 and distance <= 100):
        ledVerde.value(1)
        ledAmarelo.value(0)
        ledVermelho.value(0)
    elif (distance < 75 and distance > 25):
        ledVerde.value(0)
        ledAmarelo.value(1)
        ledVermelho.value(0)
    elif (distance <= 25):
        ledVerde.value(0)
        ledAmarelo.value(0)
        ledVermelho.value(1)

    client.check_msg()
    sleep(5)
    




if __name__  == "__main__":
  main()
